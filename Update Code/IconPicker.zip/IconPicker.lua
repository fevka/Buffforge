local addonName, addon = ...
BuffForge = addon -- Ensure global access if needed

-- Helper to get the player's profile key (duplicate from Core logic)
local function GetCharKey()
    local specIndex = GetSpecialization()
    local specID = specIndex and GetSpecializationInfo(specIndex) or 0
    return UnitName("player") .. "-" .. GetRealmName() .. "-" .. specID
end

function addon:PickTargetIcon()
    -- 1. Get the frame under the mouse
    local focus
    if GetMouseFoci then
        local foci = GetMouseFoci()
        focus = foci and foci[1]
    else
        -- Legacy fallback
        focus = GetMouseFocus and GetMouseFocus()
    end

    if not focus then 
        print("|cff00ff00[BuffForge]|r No frame detected under mouse. Please hover over a spell icon.")
        return 
    end
    
    local spellID = nil
    
    -- 2. Attempt to identify spell from Action Button (Standard Action Bars)
    if focus.action then
        local type, id, subType = GetActionInfo(focus.action)
        if type == "spell" then
            spellID = id
        elseif type == "macro" then
            spellID = GetMacroSpell(id)
        end
    end
    
    -- 3. Attempt to identify from generic 'spellID' field (Common in SpellBook and WeakAuras)
    if not spellID and focus.spellID then
        spellID = focus.spellID
    end

    -- 4. Check for 'GetSpellId' method (Some addons use this)
    if not spellID and focus.GetSpellId then
        local valid, result = pcall(focus.GetSpellId, focus)
        if valid and result then spellID = result end
    end
    
    -- 5. NEW: Check if we are hovering a BLIZZARD VIEWER FRAME directly!
    -- Since the error log showed "EssentialCooldownViewer", we can check its children.
    if not spellID and focus.GetChildren then
        -- Iterate children to find if one is under the mouse (Standard mouseover check doesn't work well on anonymous frames)
        -- But since 'focus' IS the container, we can check any child that has cooldownInfo
        local children = {focus:GetChildren()}
        for _, child in ipairs(children) do
            if child.cooldownInfo and child:IsMouseOver() then
                spellID = child.cooldownInfo.spellID
                if not spellID then spellID = child.cooldownInfo.overrideSpellID end
                if spellID then 
                    print("|cff00ff00[BuffForge]|r Found spell inside " .. focus:GetName())
                    break 
                end
            end
        end
        
        -- Fallback: If the container itself doesn't have children under mouse BUT we are hovering it,
        -- maybe we are hovering a specific child that IS the button?
        if not spellID and focus.cooldownInfo then
             spellID = focus.cooldownInfo.spellID
             if not spellID then spellID = focus.cooldownInfo.overrideSpellID end
        end
    end

    -- 6. Fallback: If it's a SpellBook button in 10.0+ (and older logic failed)
    
    if not spellID then
        print("|cff00ff00[BuffForge]|r Could not identify a spell from frame: " .. (focus:GetName() or "Anonymous"))
        print("Debug Info: Frame Type=" .. (focus:GetObjectType() or "Unknown"))
        if focus.cooldownInfo then print("   Has cooldownInfo: YES") else print("   Has cooldownInfo: NO") end
        print("Try hovering over a standard Action Bar button or Spellbook icon.")
        return
    end
    
    local spellInfo = C_Spell.GetSpellInfo(spellID)
    local name = spellInfo and spellInfo.name or "Unknown"
    local iconID = spellInfo and spellInfo.iconID or 134400
    
    print("|cff00ff00[BuffForge]|r Identified Spell: " .. name .. " (ID: " .. spellID .. ")")

    -- 6. CHECK THE "VIEWER TECHNIQUE" (BlizzardAuraTracker)
    local trackerFrame = nil
    local techStatus = "|cffff0000NO|r"
    
    if BlizzardAuraTracker and BlizzardAuraTracker.GetAuraFrame then
        trackerFrame = BlizzardAuraTracker:GetAuraFrame(spellID)
    end
    
    if trackerFrame then
        techStatus = "|cff00ff00YES|r"
        print("   |cff00ff00[Technique Check]|r SUCCESS! This spell is tracked by Blizzard's internal viewer.")
        print("   |cffaaaaaaFrame:|r " .. (trackerFrame:GetName() or "Anonymous Child"))
        print("   BuffForge will use the optimized 'Viewer Aura' technique for this icon.")
    else
        print("   |cff00ff00[Technique Check]|r Result: Not in internal viewer.")
        print("   BuffForge will use the standard/fallback tracking method.")
    end
    
    -- 7. INTEGRATE/TEST: Add to Config/Profile
    if BuffForgeDB and BuffForgeDB.profile then
        local key = GetCharKey()
        BuffForgeDB.profile[key] = BuffForgeDB.profile[key] or {}
        local profile = BuffForgeDB.profile[key]
        
        -- Check if already exists
        if profile[spellID] then
            print("|cff00ff00[BuffForge]|r Icon already exists. Updating settings for visibility test...")
        else
            print("|cff00ff00[BuffForge]|r Creating new icon for testing...")
        end
        
        -- Create/Update with test settings
        profile[spellID] = {
            enabled = true,
            type = "icon",
            point = "CENTER",
            relativePoint = "CENTER",
            x = 0, y = 0,
            size = 60, -- Large size for test visibility
            width = 60,
            
            alwaysShow = true, -- Force show for testing
            desaturate = true,
            
            showBorder = true,
            borderColor = {0, 1, 0, 1}, -- Green border
            
            trackType = "hybrid", -- Test hybrid mode
        }
        
        -- Trigger Update
        if addon.UpdateIcon then
            addon:UpdateIcon(spellID)
            print("|cff00ff00[BuffForge]|r Test Icon created at CENTER of screen!")
        end
    end
end

-- SLASH COMMAND REGISTRATION
SLASH_BUFFFORGEPICK1 = "/bfpick"
SlashCmdList["BUFFFORGEPICK"] = function()
    addon:PickTargetIcon()
end

print("|cff00ff00[BuffForge]|r Icon Picker Loaded.")
print("   Usage: Hover over a spell and type |cff00ffff/bfpick|r (or bind it to a macro).")
